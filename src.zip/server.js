var express = require('express');
var path = require('path');
var Q = require('Q');
var app = express();
var sql = require("mssql");

app.set('port', process.env.PORT || 9080);
var bodyParser = require('body-parser');

// Body Parser Middleware
app.use(bodyParser.json());

//CORS Middleware
app.use(function (req, res, next) {
  //Enabling CORS 
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, contentType,Content-Type, Accept, Authorization");
  next();
});


//this serves static file using express,dont use for production
if (process.argv[2] == "dev") {
  app.use(express.static(path.join(__dirname)));
}

var dbconfigstore = {
  server: "1-p-db-d1sql10",
  database: "userdata",
  user: "devapps",
  password: "ArtEdw1234",
  connectionLimit: 1000,
  //domain:"ART",
  port: 1433
};


app.get('/api/getChannelList', (req, res) => {
  sql.close();
  sql.connect(dbconfigstore, function (err) {
    var req = new sql.Request();
    if (err) {
      console.log(err);
      return;
    }

    function doQuery1() {
      var defered = Q.defer();
      req.query('select ChannelID,ChannelName as channelname from tblchannel', defered.makeNodeResolver());
      return defered.promise;
    }


    Q.all([doQuery1()]).then(function (results) {
      const channels = results[0].recordset;
      const resultObj = { channels };
      res.send(resultObj);
      sql.close();
    });


  });

});

app.post('/api/getSubchannel', (req, res) => {
  sql.close();

  req.on('data', function (body) {
    data = JSON.parse(body.toString());
    sql.connect(dbconfigstore, function (err) {
      var sqlReq = new sql.Request();
      if (err) {
        console.log(err);
        return;
      }
      console.log(data.channelID);
      function doQuery1() {
        var defered = Q.defer();
        sqlReq.query("select SubChannelID, SubChannelName from tblsubchannel where ChannelID=" + data.channelID, defered.makeNodeResolver());
        return defered.promise;
      }

      function doQuery2() {
        var defered = Q.defer();
        sqlReq.query('select distinct AID from tblChannelInfo', defered.makeNodeResolver());
        return defered.promise;
      }

      Q.all([doQuery1(), doQuery2()]).then(function (results) {
        const aidObj = results[1].recordset;
        const aidArray = aidObj.map(function (val) {
          return val.AID;
        });
        let aidGen = Math.floor(Math.random() * 99999999);
        do {
          aidGen = Math.floor(Math.random() * 99999999);
        } while (aidArray.includes(aidGen) === true)
        res.send({ AID: aidGen, subChannels: results[0].recordset });
        sql.close();
      });

    });
  });
});

app.post('/api/setTableData', (req, res) => {
  sql.connect(dbconfigstore, function (err) {
    var sqlReq = new sql.Request();
    var data = '';
    if (err) {
      console.log(err);
      return;
    }

    req.on('data', function (body) {
      data = JSON.parse(body.toString());

      data.map(function (obj) {
        console.log(obj);
        if (Object.keys(obj).length > 0) {
          sqlReq.query(`insert into tblChannelInfo (AID,SiteName,SiteURL,Channel,SubChannel,ChannelAcctNumber,ChannelCreatedBy) values('${obj.AID}','${obj.siteName}','${obj.siteUrl}','${obj.channel}','${obj.subChannel}','${obj.RFID}','Ben')`, function (err, recordset) {
            if (err) {
              console.log(err);

            }
          });
        }
      });

    });
  });
});

var server = app.listen(app.get('port'), function () {
  console.log(app.get('port'));
  sql.close();
});