var express = require('express');
var path = require('path');
var Q = require('Q');
var app = express();
var sql = require("mssql");

app.set('port', process.env.PORT || 9080);
var bodyParser = require('body-parser');

// Body Parser Middleware
app.use(bodyParser.json());

//CORS Middleware
app.use(function (req, res, next) {
  //Enabling CORS 
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, contentType,Content-Type, Accept, Authorization");
  next();
});


//this serves static file using express,dont use for production
if (process.argv[2] == "dev") {
  app.use(express.static(path.join(__dirname)));
}

var dbconfigstore = {
  server: "1-p-db-d1sql10",
  database: "userdata",
  user: "devapps",
  password: "ArtEdw1234",
  connectionLimit: 1000,
  //domain:"ART",
  port: 1433
};


app.get('/api/getChannelList', (req, res) => {
  sql.close();
  sql.connect(dbconfigstore, function (err) {
    var req = new sql.Request();
    if (err) {
      console.log(err);
      return;
    }

    function doQuery1() {
      var defered = Q.defer();
      req.query('select ChannelID,ChannelName as channelname from tblchannel', defered.makeNodeResolver());
      return defered.promise;
    }


    Q.all([doQuery1()]).then(function (results) {
      const channels = results[0].recordset;
      const resultObj = { channels };
      res.send(resultObj);
      sql.close();
    });


  });

});

app.post('/api/getSubchannel', (req, res) => {
  sql.close();

  req.on('data', function (body) {
    data = JSON.parse(body.toString());
    sql.connect(dbconfigstore, function (err) {
      var sqlReq = new sql.Request();
      if (err) {
        console.log(err);
        return;
      }
      console.log(data.channelID);
      function doQuery1() {
        var defered = Q.defer();
        sqlReq.query("select SubChannelID, SubChannelName from tblsubchannel where ChannelID=" + data.channelID, defered.makeNodeResolver());
        return defered.promise;
      }

      function doQuery2() {
        var defered = Q.defer();
        sqlReq.query('select distinct AID from tblChannelInfo', defered.makeNodeResolver());
        return defered.promise;
      }

      function doQuery3(){
        var defered = Q.defer();
        sqlReq.query('select distinct AID from tblChannelInfo',defered.makeNodeResolver());
        return defered.promise;
       }

      Q.all([doQuery1(), doQuery2(), doQuery3()]).then(function (results) {


        const aidObj = results[1].recordset;
        const aidArray = aidObj.map(function (val) {
          return val.AID;
        });
        let aidGen = Math.floor(Math.random() * 99999999);
        do {
          aidGen = Math.floor(Math.random() * 99999999);
        } while (aidArray.includes(aidGen) === true)

        const rfidObj = results[2].recordset;
        const rfidArray = rfidObj.map(function (val) {
            return val.RFID;
          });
          let rfidGen = Math.floor(Math.random() * 99999999);
          do {
            rfidGen = Math.floor(Math.random() * 99999999);
          } while (rfidArray.includes(rfidGen) === true)

        res.send({ AID: aidGen, subChannels: results[0].recordset, RFID: 'R'+ rfidGen });
        sql.close();
      });

    });
  });
});

app.post('/api/setTableData', (req, res) => {
  sql.connect(dbconfigstore, function (err) {
    var sqlReq = new sql.Request();
    var data = '';
    if (err) {
      console.log(err);
      return;
    }

    req.on('data', function (body) {
      data = JSON.parse(body.toString());
      var sqlParams = [];
     
      sqlReq.input('records', sql.VarChar(500), body.toString());
            sqlReq.execute('spitblChanneLinfo2').then(function(err, recordsets, returnValue, affected)
              {
                 res.send({status:200, respText: "Successfully Inserted..!!! " })
                  }).catch(function(err) {
                     res.send({status:200, respText: "Insert Failed, Please Enter Valid Data..!!! " })
                });

    });
  });
});

var server = app.listen(app.get('port'), function () {
  console.log(app.get('port'));
  sql.close();
});