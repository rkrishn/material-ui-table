import React from 'react';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import {
  Table,
  TableBody,
  TableRow,
  TableRowColumn,
} from 'material-ui/Table';
import TextField from 'material-ui/TextField';
import MenuItem from 'material-ui/MenuItem';
import FloatingActionButton from 'material-ui/FloatingActionButton';
import ContentAdd from 'material-ui/svg-icons/content/add';
import ContentD from 'material-ui/svg-icons/content/clear';
import SelectField from 'material-ui/SelectField';
import RaisedButton from 'material-ui/RaisedButton';
import './App.css';
import Dialog from 'material-ui/Dialog';
import ActivityIndicator from 'react-activity-indicator';


const customStyle = {
  'customSelectField': {
    width: 'auto'
  },
  customDropdown: {
    width: 'auto',
    paddingTop: '40px'
  }
};

const urls = {
  'channelUrl': 'http://192.168.169.84:9080/api/getChannelList',
  'subChannelUrl': 'http://192.168.169.84:9080/api/getSubchannel',
  'postUrl': 'http://192.168.169.84:9080/api/setTableData'
};
class App extends React.Component {

  constructor(props) {
    super(props);

    this.state = {
      filterText: '',
      serverRes: '',
      open: false,
      submitBtn: true,
      products: [
        {
          id: 1,
          channel: '',
          subChannel: '',
          AID: '',
          RFID: '',
          Description: '',
          siteName: '',
          siteUrl: '',
          DescriptionError: "",
          AIDError: "",
          RFIDError: "",
          SiteNameError: "",
          SiteUrlError: "",
          flagErrorCheck: false

        }
      ]
    };

  }
  handleUserInput(filterText) {
    this.setState({ filterText: filterText });
  };
  handleRowDel(product) {
    var index = this.state.products.indexOf(product);
    this.state.products.splice(index, 1);
    this.setState(this.state.products);
    console.log(this.state.products);
    this.checkForValidation(this.state.products);
  };

  handleAddEvent(evt) {
    var id = this.state.products.length + 1;
    var product = {
      id,
      channel: '',
      subChannel: '',
      AID: '',
      RFID: '',
      Description: '',
      siteName: '',
      siteUrl: ''
    }
    this.state.products.push(product);
    this.setState(this.state.products);
    this.checkForValidation(this.state.products);
  }

  handleProductTable(evt) {
    var item = {
      id: evt.target.id,
      name: evt.target.name,
      value: evt.target.value
    };
    var products = this.state.products.slice();
    var newProducts = products.map(function (product) {

      for (var key in product) {
        if (key == item.name && product.id == item.id) {
          product[key] = item.value;

          if (key == 'AID' && product.id == item.id) {
            if (item.value.length < 8 || item.value.length > 12) {
              product['AIDError'] = 'AID should be Of 10 digits';
            } else {
              product['AIDError'] = '';

            }
          }
          if (key == 'RFID' && product.id == item.id) {
            if (item.value.length < 8 || item.value.length > 12) {
              product['RFIDError'] = 'RFID should be Of 10 digits';
            } else {
              product['RFIDError'] = '';
            }
          }
          if (key == 'Description' && product.id == item.id) {
            if (item.value.length < 5) {
              product['DescriptionError'] = 'Description text is required';
            } else {
              product['DescriptionError'] = '';
            }
          }
          if (key == 'siteName' && product.id == item.id) {
            if (item.value.length < 5) {
              product['SiteNameError'] = 'Site name is required';
            } else {
              product['SiteNameError'] = '';
            }
          }
          if (key == 'siteUrl' && product.id == item.id) {
              if (item.value.length < 5 || (item.value.toString().indexOf('www.')) == -1) {
              product['SiteUrlError'] = 'SiteUrl start with "www." ';
            }else {
              product['SiteUrlError'] = '';
            }
          }
        }
      }
      return product;
    });

    this.checkForValidation(newProducts);
    this.setState({ products: newProducts });
    console.log(this.state.products);

  }
  checkForValidation(newProducts){

    let tempFlag = true;
    for (let i = 0; i < newProducts.length; i++) {
      if (
        (newProducts[i].AID === '' && newProducts[i].AIDError !== '') ||
        newProducts[i].RFID === '' ||
        newProducts[i].Description === '' ||
        newProducts[i].siteName === '' ||
        newProducts[i].siteUrl === '') {
          if (newProducts[i].AIDError !== '' ||
          newProducts[i].RFIDError !== '' ||
          newProducts[i].DescriptionError !== '' ||
          newProducts[i].SiteNameError !== '' ||
          newProducts[i].SiteUrlError !== '') {
          tempFlag = true;
          break;
        }
      } else {
        if (newProducts[i].AIDError !== '' ||
          newProducts[i].RFIDError !== '' ||
          newProducts[i].DescriptionError !== '' ||
          newProducts[i].SiteNameError !== '' ||
          newProducts[i].SiteUrlError !== '') {
            tempFlag = true;
            break;
        } else {
          tempFlag = false;
        }
      }
    }

    this.setState({
       submitBtn: tempFlag
    });

  }
  onSubmit = () => {
    this.postTabledata();
  }



  postTabledata = () => {
    let methodParams = {
      method: 'POST',
      mode: 'cors',
      header: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(this.state.products)
    };
    let self = this;
    fetch(urls.postUrl, methodParams).then(response => response.json().then(function (res) {
      debugger
      self.setStatus(res.respText);
    })).catch(err => console.log(err));
  }

  handleClose = () => {
    this.setState({ open: false });
  }
  setStatus(serverRes) {
    
    this.setState({
      serverRes,
      open: true
    })
  }
  render() {
    const style = {
      paddingTop: 'right',
    };
    const btnStyle = {
      marginLeft: '20px',
    };
    return (
      <MuiThemeProvider>
        <div className="App">
          <header className='headerCls'>
            <h1>Creation of AID/RFID
          <FloatingActionButton style={btnStyle} mini={true} secondary={true} onClick={this.handleAddEvent.bind(this)}>
                <ContentAdd />
              </FloatingActionButton>
            </h1>

          </header>
          <ProductTable style={style} onProductTableUpdate={this.handleProductTable.bind(this)} onRowAdd={this.handleAddEvent.bind(this)} onRowDel={this.handleRowDel.bind(this)} products={this.state.products} filterText={this.state.filterText} />
          <RaisedButton disabled={this.state.submitBtn} label="Submit" mini={true} primary={true} style={style} onClick={this.onSubmit} />
         {this.state.serverRes &&

          <Dialog
            title="Creation of RFID"
            modal={false}
            open={this.state.open}
            onRequestClose={this.handleClose}
          >
            {this.state.serverRes}
          </Dialog>

         } 
        </div>
      </MuiThemeProvider>
    );

  }

}

class ProductTable extends React.Component {

  constructor(props) {
    super(props);
    this.state = { channels: [], subchannels: [],
      selectChannel: 'Select Channel',
    selectSubChannel: 'Select Sub Channel', };
  }


  componentWillMount() {
    let fetchData = {
      method: 'GET',
      mode: 'cors',
      header: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      }
    };
    let self = this;
    const channelsData = localStorage.getItem('channels');

    const subChannelsData = localStorage.getItem('subchannels');

    if (channelsData && subChannelsData) {
      this.setChannels(JSON.parse(channelsData), JSON.parse(subChannelsData));
    } else {
      fetch(urls.channelUrl, fetchData).then(response => response.json().then(function (data) {
        localStorage.setItem('channels', JSON.stringify(data.channels.unshift({"ChannelID":0,"channelname":"Select Channel"})));
        self.setChannels(data.channels);
      })).catch(err => console.log(err));
    }
  }

  callSubChannels(data) {

    const channelID = data[0].ChannelID;
    let fetchData = {
      method: 'POST',
      mode: 'cors',
      header: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ channelID })
    };
    let self = this;

    fetch(urls.subChannelUrl, fetchData).then(response => response.json().then(function (res) {
      localStorage.setItem('subchannels', JSON.stringify(res));
      self.setChannels(data, res);
    })).catch(err => console.log(err));
  }

  setChannels(channels, res) {
    //res.unshift({"SubChannelID":0,"SubChannelName":"Select Sub Channel"});
    this.setState({
      channels
    });

  }
  render() {
    const tableStyle = {
      overflow: 'hidden',
      backgroundColor: 'rgb(238, 239, 243)'
    };
    var onProductTableUpdate = this.props.onProductTableUpdate;
    var rowDel = this.props.onRowDel;
    var filterText = this.props.filterText;
    var channels = this.state.channels;
    var subchannels = this.state.subchannels;
    const AID = this.state.AID;
    var product = this.props.products.map(function (product) {
      if (product.channel.indexOf(filterText) === -1) {
        return;
      }
      return (<ProductRow AID={AID} onProductTableUpdate={onProductTableUpdate} subChannels={subchannels} channels={channels} product={product} onDelEvent={rowDel.bind(this)} key={product.id} />)
    });
    return (
      <div>
        <Table style={tableStyle}>
          <TableBody>
            {this.state.channels.length === 0 &&
              <h1> Please wait Loading...! </h1>
            }
            {this.state.channels.length > 0 && product}
          </TableBody>
        </Table>
      </div>
    );

  }

}

class ProductRow extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      channel: 0,
      subChannel: 0,
      subChannels: [],      
      AID: '',
      loaded: false
    };
  }
  onDelEvent() {
    this.props.onDelEvent(this.props.product);
  }
  componentDidMount() {
    if (this.props.channels.length > 0) {
      this.updateProductArray(this.props.product.id, 'channel', this.props.channels[0].channelname);
     // this.updateProductArray(this.props.product.id, 'subChannel', this.props.subChannels[0].SubChannelName);
      //this.updateProductArray(this.props.product.id, 'AID', this.props.AID);

      /*this.setState({
        subChannels: this.props.subChannels,
        AID: this.props.AID
      })*/
    }
  }
  handleChannelChange = (event, channel, channelID) => {
    this.updateProductArray(this.props.product.id, 'channel', this.props.channels[channel].channelname);

    this.setState({
      channel: channelID,
      subChannel: -1,
      AID: '',
      loaded: false
    });

    let fetchData = {
      method: 'POST',
      mode: 'cors',
      header: {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ channelID })
    };

    let self = this;

    fetch(urls.subChannelUrl, fetchData).then(response => response.json().then(function (res) {
      self.setSubChannels(res);
      self.updateProductArray(self.props.product.id, 'subChannel', res.subChannels[0].SubChannelName);
      self.updateProductArray(self.props.product.id, 'AID', res.AID);
      self.updateProductArray(self.props.product.id, 'RFID', res.RFID);
    }))
      .catch(err => console.log(err));
  }

  updateProductArray(id, name, value) {
    const Obj = { target: { id, name, value } };
    this.props.onProductTableUpdate(Obj);
  }

  setSubChannels(subChannels) {
    this.setState({
      subChannels: subChannels.subChannels,
      subChannel: subChannels.subChannels[0].SubChannelID,
      AID: subChannels.AID,
      loaded: true,
      RFID: subChannels.RFID
    });
  }
  handleSubChannelChange = (event, index, subChannel) => {
    this.setState({ subChannel });
    if (this.state)
      this.updateProductArray(this.props.product.id, 'subChannel', this.state.subChannels[index].SubChannelName);
  }
  AIDChange = (event, AID) => {
    this.setState({
      AID
    });
    this.updateProductArray(this.props.product.id, 'AID', AID);
  }
  render() {


    return (
      <TableRow displayBorder={false} className='dropDownHeader'>
          <TableRowColumn>
          <SelectField
            style={customStyle.customDropdown}
           
            value={this.state.channel}
            autoWidth={true}
            onChange={this.handleChannelChange}
          >{
              this.props.channels.map((val, idx) => {
                return (<MenuItem value={val.ChannelID} primaryText={val.channelname} />);
              })
            }
          </SelectField >
        </TableRowColumn>
        <TableRowColumn>
          <SelectField style={customStyle.customDropdown}
            
            value={this.state.subChannel}
            autoWidth={true}
            onChange={this.handleSubChannelChange}
          >
            {this.state.subChannels.length && this.state.loaded > 0 &&
              this.state.subChannels.map((val, idx) => {
                return (<MenuItem value={val.SubChannelID} primaryText={val.SubChannelName} />);
              })
            }
          </SelectField>
        </TableRowColumn>

        <TableRowColumn>
          <TextField type='AID'
            ref={(input) => { this.aidbox = input; }}
            floatingLabelText='AID'
            hintText='AID'
            id={this.props.product.id}
            value={this.state.AID}
            onChange={this.AIDChange}
            errorText={this.props.product.AIDError ? <div>
              <div>{this.props.product.AIDError}</div>
            </div>
              : ''
            } />
        </TableRowColumn>

        <EditableCell errorMsg={this.props.product.RFIDError} onProductTableUpdate={this.props.onProductTableUpdate} cellData={{
          type: "RFID",
          hintText: "RFID",
          value: this.props.product.RFID,
          id: this.props.product.id
        }} />
        <EditableCell errorMsg={this.props.product.DescriptionError} onProductTableUpdate={this.props.onProductTableUpdate} cellData={{
          type: "Description",
          hintText: "Description",
          value: this.props.product.Description,
          id: this.props.product.id

        }} />
        <EditableCell errorMsg={this.props.product.SiteNameError} errorText={this.state.SiteNameError} onProductTableUpdate={this.props.onProductTableUpdate} cellData={{
          type: "siteName",
          hintText: "Site Name",
          value: this.props.product.siteName,
          id: this.props.product.id
        }} />
        <EditableCell errorMsg={this.props.product.SiteUrlError} onProductTableUpdate={this.props.onProductTableUpdate} cellData={{
          type: "siteUrl",
          hintText: "Site Url",
          value: this.props.product.siteUrl,
          id: this.props.product.id
        }} />
        <TableRowColumn>
          <FloatingActionButton mini={true} secondary={true} onClick={this.onDelEvent.bind(this)}>
            <ContentD />
          </FloatingActionButton>
        </TableRowColumn>
      </TableRow>
    );

  }

}

class EditableCell extends React.Component {

  render() {
    return (
      <TableRowColumn>
        <TextField multiLine={true}
          rowsMax={2} type='text' errorText={this.props.errorMsg} floatingLabelText={this.props.cellData.hintText} hintText={this.props.cellData.hintText} style={customStyle.customSelectField} name={this.props.cellData.type} id={this.props.cellData.id} value={this.props.cellData.value} onChange={this.props.onProductTableUpdate} />
      </TableRowColumn>
    );

  }

}


export default App;
