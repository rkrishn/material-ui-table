
import React from 'react';
import {
    Table,
    TableBody
} from 'material-ui/Table';
import ProductRow from './productRow';
import ContentAdd from 'material-ui/svg-icons/content/add';
import FloatingActionButton from 'material-ui/FloatingActionButton';

export default class ProductTable extends React.Component {

    constructor(props) {
        super(props);
        this.state = { channels: [], subchannels: [] };
    }


    componentWillMount() {
        const url = "http://192.168.169.84:9080/api/getChannelList";
        let fetchData = {
            method: 'GET',
            mode: 'cors',
            header: {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            }
        };
        let self = this;
        const channelsData = localStorage.getItem('channels');

        const subChannelsData = localStorage.getItem('subchannels');

        if (channelsData && subChannelsData) {
            this.setChannels(JSON.parse(channelsData), JSON.parse(subChannelsData));
        } else {
            fetch(url, fetchData).then(response => response.json().then(function (data) {
                localStorage.setItem('channels', JSON.stringify(data.channels));
                self.callSubChannels(data.channels);
            })).catch(err => console.log(err));
        }
    }

    callSubChannels(data) {

        const channelID = data[0].ChannelID;
        const urlforsuchannel = "http://192.168.169.84:9080/api/getSubchannel";
        let fetchData = {
            method: 'POST',
            mode: 'cors',
            header: {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ channelID })
        };
        let self = this;

        fetch(urlforsuchannel, fetchData).then(response => response.json().then(function (res) {
            localStorage.setItem('subchannels', JSON.stringify(res));
            self.setChannels(data, res);
        })).catch(err => console.log(err));
    }

    setChannels(channels, res) {

        this.setState({
            channels,
            subchannels: res.subChannels,
            AID: res.AID,
            RFID: res.RFID
        });

    }
    render() {
        const tableStyle = {
            overflow: 'hidden',
        };
        var onProductTableUpdate = this.props.onProductTableUpdate;
        var rowDel = this.props.onRowDel;
        var filterText = this.props.filterText;
        var channels = this.state.channels;
        var subchannels = this.state.subchannels;
        const AID = this.state.AID;
        const RFID = this.state.RFID;
        var product = this.props.products.map(function (product, index) {
            if (product.channel.indexOf(filterText) === -1) {
                return '';
            }
            return (<ProductRow
                AID={AID}
                RFID={RFID}
                onProductTableUpdate={onProductTableUpdate}
                subChannels={subchannels}
                channels={channels}
                product={product}
                onDelEvent={rowDel.bind(this)}
                key={product.id} />)
        });
        return (
            <div>
                <FloatingActionButton mini={true} secondary={true} onClick={this.props.onRowAdd}>
                    <ContentAdd />
                </FloatingActionButton>
                <Table style={tableStyle}>
                    <TableBody>
                        {this.state.channels.length === 0 &&
                            <h1> Please wait Loading...! </h1>
                        }
                        {this.state.channels.length > 0 && product}
                    </TableBody>
                </Table>
            </div>
        );

    }

}
