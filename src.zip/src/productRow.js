
import React from 'react';
import SelectField from 'material-ui/SelectField';
import MenuItem from 'material-ui/MenuItem';
import EditableCell from './editableCell';
import ContentD from 'material-ui/svg-icons/content/clear';
import FloatingActionButton from 'material-ui/FloatingActionButton';
import {
    TableRow,
    TableRowColumn
} from 'material-ui/Table';

const customStyle = {
    'customSelectField': {
        width: 'auto'
    }
};
export default class ProductRow extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            channel: 1,
            subChannel: 1,
            subChannels: [],
            AID: '',
            RFID:''
        };
    }
    onDelEvent() {
        this.props.onDelEvent(this.props.product);

    }
    componentDidMount() {
        if (this.props.channels.length > 0) {
            this.updateProductArray(this.props.product.id, 'channel', this.props.channels[0].channelname);
            this.updateProductArray(this.props.product.id, 'subChannel', this.props.subChannels[0].SubChannelName);
            this.updateProductArray(this.props.product.id, 'AID', this.props.AID);
            this.updateProductArray(this.props.product.id, 'RFID', this.props.RFID);

            this.setState({
                subChannels: this.props.subChannels,
                AID: this.props.AID,
                RFID: this.props.RFID
            })
        }
    }
    handleChannelChange = (event, channel, channelID) => {
        this.updateProductArray(this.props.product.id, 'channel', this.props.channels[channel].channelname);

        this.setState({
            channel: channelID,
            subChannel: -1,
            AID: '',
            RFID: ''
        });

        const urlforsuchannel = "http://192.168.169.84:9080/api/getSubchannel";
        let fetchData = {
            method: 'POST',
            mode: 'cors',
            header: {
                'Access-Control-Allow-Origin': '*',
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ channelID })
        };

        let self = this;

        fetch(urlforsuchannel, fetchData).then(response => response.json().then(function (res) {
            self.setSubChannels(res);
            self.updateProductArray(self.props.product.id, 'subChannel', res.subChannels[0].SubChannelName);
            self.updateProductArray(self.props.product.id, 'AID', res.AID);
            self.updateProductArray(self.props.product.id, 'RFID', res.RFID);
        }))
            .catch(err => console.log(err));
    }

    updateProductArray(id, name, value) {
        const Obj = { target: { id, name, value } };
        this.props.onProductTableUpdate(Obj);
    }

    setSubChannels(subChannels) {
        this.setState({
            subChannels: subChannels.subChannels,
            subChannel: subChannels.subChannels[0].SubChannelID,
            AID: subChannels.AID,
            RFID: subChannels.RFID
        });
    }
    handleSubChannelChange = (event, index, subChannel) => {
        this.setState({ subChannel });
        if (this.state.subChannels)
            this.updateProductArray(this.props.product.id, 'subChannel', this.state.subChannels[index].SubChannelName);
    }
    render() {


        return (
            <TableRow key={this.props.product.id} displayBorder={false} className='dropDownHeader'>
                <TableRowColumn>
                    <SelectField autoWidth={true}
                        style={customStyle.customSelectField}
                        floatingLabelText="Channel"
                        value={this.state.channel}
                        onChange={this.handleChannelChange}
                    >{
                            this.props.channels.map((val, idx) => {
                                return (<MenuItem value={val.ChannelID} primaryText={val.channelname} />);
                            })
                        }
                    </SelectField >
                    </TableRowColumn>
                    <TableRowColumn>
                    <SelectField style={customStyle.customSelectField}
                        floatingLabelText="Subchannel"
                        value={this.state.subChannel}
                        autoWidth={true}
                        onChange={this.handleSubChannelChange}
                    >
                        {this.state.subChannels.length > 0 &&
                            this.state.subChannels.map((val, idx) => {
                                return (<MenuItem value={val.SubChannelID} primaryText={val.SubChannelName} />);
                            })
                        }
                    </SelectField>
                    </TableRowColumn>
                    
                <EditableCell onProductTableUpdate={this.props.onProductTableUpdate} cellData={{
                    type: "AID",
                    hintText: "AID",
                    value: this.state.AID,
                    id: this.props.product.id,
                }} />
                <EditableCell onProductTableUpdate={this.props.onProductTableUpdate} cellData={{
                    type: "RFID",
                    hintText: "RFID",
                    value: this.state.RFID,
                    id: this.props.product.id
                }} />
                <EditableCell onProductTableUpdate={this.props.onProductTableUpdate} cellData={{
                    type: "Description",
                    hintText: "Description",
                    value: this.props.product.Description,
                    id: this.props.product.id
                }} />
                <EditableCell onProductTableUpdate={this.props.onProductTableUpdate} cellData={{
                    type: "siteName",
                    hintText: "Site Name",
                    value: this.props.product.siteName,
                    id: this.props.product.id
                }} />
                <EditableCell onProductTableUpdate={this.props.onProductTableUpdate} cellData={{
                    type: "siteUrl",
                    hintText: "Site Url",
                    value: this.props.product.siteUrl,
                    id: this.props.product.id
                }} />
                <TableRowColumn>
                    <FloatingActionButton mini={true} secondary={true} onClick={this.onDelEvent.bind(this)}>
                        <ContentD />
                    </FloatingActionButton>
                </TableRowColumn>
            </TableRow>
        );

    }

}
