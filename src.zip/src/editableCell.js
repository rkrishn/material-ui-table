import React from 'react';
import TextField from 'material-ui/TextField';
import {
    TableRowColumn
} from 'material-ui/Table';
const customStyle = {
    'customSelectField': {
        width: 'auto'
    }
};
export default class EditableCell extends React.Component {

    render() {
        return (
            <TableRowColumn>
                <TextField type={this.props.cellData.type}
                    floatingLabelText={this.props.cellData.hintText}
                    hintText={this.props.cellData.hintText}
                    style={customStyle.customSelectField}
                    name={this.props.cellData.name}
                    id={this.props.cellData.id}
                    value={this.props.cellData.value}
                    onChange={this.props.onProductTableUpdate} />
            </TableRowColumn>
        );

    }

}