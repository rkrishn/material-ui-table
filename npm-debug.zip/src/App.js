import React from 'react';
import ReactDOM from 'react-dom';
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import {
  Table,
  TableBody,
  TableFooter,
  TableHeader,
  TableHeaderColumn,
  TableRow,
  TableRowColumn,
} from 'material-ui/Table';
import TextField from 'material-ui/TextField';
import DropDownMenu from 'material-ui/DropDownMenu';
import MenuItem from 'material-ui/MenuItem';
import FloatingActionButton from 'material-ui/FloatingActionButton';
import ContentAdd from 'material-ui/svg-icons/content/add';
import ContentD from 'material-ui/svg-icons/content/clear';
import SelectField from 'material-ui/SelectField';
import RaisedButton from 'material-ui/RaisedButton';

const style = {
  margin: 12,
};
const customStyle = {
  'customSelectField': {
    width: 'auto'
  }
};
class App extends React.Component {
  
    constructor(props) {
      super(props);
  
      //  this.state.products = [];
      this.state = {};
      this.state.filterText = "";
      this.state.products = [
        {
          id: 1,
          category: 'Sporting Goods',
          price: '49.99',
          qty: 12,
          name: 'football'
        }, {
          id: 2,
          category: 'Sporting Goods',
          price: '9.99',
          qty: 15,
          name: 'baseball'
        }, {
          id: 3,
          category: 'Sporting Goods',
          price: '29.99',
          qty: 14,
          name: 'basketball'
        }, {
          id: 4,
          category: 'Electronics',
          price: '99.99',
          qty: 34,
          name: 'iPod Touch'
        }, {
          id: 5,
          category: 'Electronics',
          price: '399.99',
          qty: 12,
          name: 'iPhone 5'
        }, {
          id: 6,
          category: 'Electronics',
          price: '199.99',
          qty: 23,
          name: 'nexus 7'
        }
      ];
  
    }
    handleUserInput(filterText) {
      this.setState({filterText: filterText});
    };
    handleRowDel(product) {
      var index = this.state.products.indexOf(product);
      this.state.products.splice(index, 1);
      this.setState(this.state.products);
    };
   
    handleAddEvent(evt) {
      var id = (+ new Date() + Math.floor(Math.random() * 999999)).toString(36);
      var product = {
        id: id,
        name: "",
        price: "",
        category: "",
        qty: 0
      }
      this.state.products.push(product);
      this.setState(this.state.products);
  
    }
  
    handleProductTable(evt) {
      var item = {
        id: evt.target.id,
        name: evt.target.name,
        value: evt.target.value
      };
  var products = this.state.products.slice();
    var newProducts = products.map(function(product) {
  
      for (var key in product) {
        if (key == item.name && product.id == item.id) {
          product[key] = item.value;
  
        }
      }
      return product;
    });
      this.setState({products:newProducts});
    //  console.log(this.state.products);
    };
    render() {
  
      return (
        <MuiThemeProvider>
       <SearchBar filterText={this.state.filterText} onUserInput={this.handleUserInput.bind(this)}/>
          <ProductTable onProductTableUpdate={this.handleProductTable.bind(this)} onRowAdd={this.handleAddEvent.bind(this)} onRowDel={this.handleRowDel.bind(this)} products={this.state.products} filterText={this.state.filterText}/>
      </MuiThemeProvider>
      );
  
    }
  
  }
  class SearchBar extends React.Component {
    handleChange() {
      this.props.onUserInput(this.refs.filterTextInput.value);
    }
    render() {
      return (
        <div>
  
          <input type="text" placeholder="Search..." value={this.props.filterText} ref="filterTextInput" onChange={this.handleChange.bind(this)}/>
  
        </div>
  
      );
    }
  
  }
  
  class ProductTable extends React.Component {
  
    render() {
      var onProductTableUpdate = this.props.onProductTableUpdate;
      var rowDel = this.props.onRowDel;
      var filterText = this.props.filterText;
      var product = this.props.products.map(function(product) {
        if (product.name.indexOf(filterText) === -1) {
          return;
        }
        return (<ProductRow onProductTableUpdate={onProductTableUpdate} product={product} onDelEvent={rowDel.bind(this)} key={product.id}/>)
      });
      return (
        <div>
        <FloatingActionButton secondary={true} onClick={this.props.onRowAdd}>
              <ContentAdd />
            </FloatingActionButton>
            
          <Table>
              

            <TableBody>
            {product}
              </TableBody>
              <TableFooter>
              <TableRow>
                <TableHeaderColumn><RaisedButton label="Submit" primary={true} style={style} /></TableHeaderColumn>
              </TableRow>
            </TableFooter>
            </Table>
        </div>
      );
  
    }
  
  }
  
  class ProductRow extends React.Component {
    constructor(props){
      super(props);
      this.state = {
        channel: 1,
        subChannel: 1,
        subChannels:[]
      };
      this.state.channels=[
        {
          cname: 'ch1',
          subchannels:[
            {
              sname: 'sub1'
            },
            {
              sname: 'sub2'
            }
          ]
        },
        {
          cname: 'ch2',
          subchannels:[
            {
              sname: 'sub3'
            },
            {
              sname: 'sub4'
            }
          ]
        },
        {
          cname: 'ch3',
          subchannels:[
            {
              sname: 'sub31'
            },
            {
              sname: 'sub32'
            }
          ]
        },
        {
          cname: 'ch4',
          subchannels:[
            {
              sname: 'sub7'
            },
            {
              sname: 'sub8'
            }
          ]
        }

      ]
    }
    onDelEvent() {
      this.props.onDelEvent(this.props.product);
  
    }
    handleChannelChange = (event, index, channel) => {
      this.setState({
        channel,
        subChannels: this.state.channels[index].subchannels
      });
    }
    handleSubChannelChange = (event, index, subChannel) => {
      this.setState({subChannel});
    }
    render() {
 
      return (
        <TableRow displayBorder={false}>
          <td>
          <SelectField autoWidth={true} 
          style={customStyle.customSelectField}
              floatingLabelText="Channel"
              value={this.state.channel}
              onChange={this.handleChannelChange}
            >{
              this.state.channels.map( (val,idx)=>{
                return (<MenuItem value={idx} primaryText={val.cname} />);
              })
            }
        </SelectField >
        </td>
        <td>
        <SelectField autoWidth={true} style={customStyle.customSelectField}
          floatingLabelText="Subchannel"
          value={this.state.subChannel}
          onChange={this.handleSubChannelChange}
        >
        {this.state.subChannels.length > 0 &&
          this.state.subChannels.map( (val,idx)=>{
            return (<MenuItem value={idx} primaryText={val.sname} />);
          })
        }
        </SelectField>
        </td>
          <EditableCell onProductTableUpdate={this.props.onProductTableUpdate} cellData={{
            "type": "name",
            hintText:"name",
            value: this.props.product.name,
            id: this.props.product.id,
          }}/>
          <EditableCell onProductTableUpdate={this.props.onProductTableUpdate} cellData={{
            type: "price",
            value: this.props.product.price,
            id: this.props.product.id
          }}/>
          <EditableCell onProductTableUpdate={this.props.onProductTableUpdate} cellData={{
            type: "qty",
            value: this.props.product.qty,
            id: this.props.product.id
          }}/>
          <EditableCell onProductTableUpdate={this.props.onProductTableUpdate} cellData={{
            type: "category",
            value: this.props.product.category,
            id: this.props.product.id
          }}/>
          <td className="del-cell">
            <FloatingActionButton mini={true} secondary={true} onClick={this.onDelEvent.bind(this)}>
              <ContentD />
            </FloatingActionButton>
          </td>
          </TableRow>
      );
  
    }
  
  }
  
  class EditableCell extends React.Component {
  
    render() {
      return (
        <td>
          <TextField type='text'  hintText={this.props.cellData.hintText} style={customStyle.customSelectField} name={this.props.cellData.type} id={this.props.cellData.id} value={this.props.cellData.value} onChange={this.props.onProductTableUpdate}/>
        </td>
      );
  
    }
  
  }
  

export default App;
